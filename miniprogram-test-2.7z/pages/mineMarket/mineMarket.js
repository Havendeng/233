// pages/mineMarket/mineMarket.js
 /* jshint esversion: 6 */
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    containerHeight: app.globalData.containerHeight,
    prizeList:[
      {id:1,name:"goos1"},
      {id:2,name:"goos2"},
      {id:3,name:"goos3"},
      {id:4,name:"goos4"},
      {id:5,name:"goos5"},
      {id:6,name:"goos5"},
      {id:7,name:"goos5"},
      {id:8,name:"goos5"}
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
});
